"""Replay the archived QASPER validation R0 answer calls against one replacement model."""
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
import time
from pathlib import Path
from statistics import mean

EVIDENCE = Path("/Users/oscar/Desktop/SecureCode/2nd/Documents/test_results/evidence/qasper_benchmark_20261027")
MODEL_ID = "lmstudio-community/Qwen3.8-27B-MLX-5bit"
SYSTEM = "You are a helpful assistant."
PREFIX = "<|im_start|>system\n" + SYSTEM + "<|im_end|>\n<|im_start|>user\n"
SUFFIX = "<|im_end|>\n<|im_start|>assistant\n"
SPEC = importlib.util.spec_from_file_location("qasper_frozen_metrics", EVIDENCE / "source_snapshot/metrics.py")
METRICS = importlib.util.module_from_spec(SPEC)
SPEC.loader.exec_module(METRICS)


def digest(text):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()


def jsonl(filename):
    with (EVIDENCE / filename).open() as source:
        yield from map(json.loads, source)


def cases():
    """Return R0 cases in original schedule order; only messages are passed to inference."""
    tasks = {r["task_id"]: r for r in jsonl("tasks.jsonl")}
    scores = {r["task_id"]: r for r in jsonl("task_scores.jsonl") if r["arm"] == "R0"}
    rows = [r for r in jsonl("results.jsonl") if r["arm"] == "R0"]
    schedule = [r["task_id"] for r in json.loads((EVIDENCE / "schedule.json").read_text()) if r["arm"] == "R0"]
    assert len(rows) == len(tasks) == len(scores) == len(set(schedule)) == 984
    assert [r["task_id"] for r in rows] == schedule
    contexts = {r["document_id"] for r in rows}
    assert len(contexts) == 273
    template = json.loads((EVIDENCE / "source_snapshot/official_sources/longbench/LongBench/config/dataset2prompt.json").read_text())["qasper"]
    result = []
    for row in rows:
        key = row["task_id"]
        task, score = tasks[key], scores[key]
        call_key = digest(key + "|R0|answer")
        assert row["call_keys"] == [call_key]
        with gzip.open(EVIDENCE / "calls" / call_key[:2] / (call_key + ".json.gz"), "rt") as archive:
            call = json.load(archive)
        prompt = template.format(context=row["context"], input=task["question"])
        request = call["request"]
        assert request["prompt"] == PREFIX + prompt + SUFFIX
        assert request["temperature"] == 0 and request["seed"] == 1 and request["n_predict"] == 128
        assert digest(row["context"]) == row["context_sha256"]
        assert call["answer"] == row["prediction"] == score["prediction"] and call["status"] == "ok"
        assert task["document_id"] == row["document_id"] == score["document_id"]
        baseline_f1 = METRICS.score_example("qasper", call["answer"], task["references"])["f1"]
        assert baseline_f1 == score["components"]["f1"]
        result.append({
            "task_id": key, "document_id": row["document_id"], "cluster_id": score["cluster_id"],
            "messages": [{"role": "system", "content": SYSTEM}, {"role": "user", "content": prompt}],
            "prompt_sha256": digest(request["prompt"]), "max_tokens": 128, "references": task["references"],
            "baseline_f1": baseline_f1, "baseline_call_seconds": call["wall_seconds"],
            "baseline_input_tokens": call["input_tokens"], "baseline_output_tokens": call["output_tokens"],
        })
    return result


def write_json(path, value):
    tmp = path.with_suffix(".part")
    with tmp.open("w") as f:
        json.dump(value, f, ensure_ascii=False, allow_nan=False)
        f.write("\n")
        f.flush()
        os.fsync(f.fileno())
    os.replace(tmp, path)


def record(case, raw_output, perf, elapsed):
    if not isinstance(raw_output, str) or not isinstance(perf, dict):
        raise TypeError("complete must return (str, dict)")
    prediction = raw_output.strip()
    return {
        "model_id": MODEL_ID, "benchmark": "QASPER-R0",
        "task_id": case["task_id"], "document_id": case["document_id"], "cluster_id": case["cluster_id"],
        "prompt_sha256": case["prompt_sha256"], "max_tokens": case["max_tokens"], "raw_output": raw_output,
        "prediction": prediction, "new_f1": METRICS.score_example("qasper", prediction, case["references"])["f1"],
        "baseline_f1": case["baseline_f1"], "call_seconds": elapsed, "baseline_call_seconds": case["baseline_call_seconds"],
        "baseline_input_tokens": case["baseline_input_tokens"], "baseline_output_tokens": case["baseline_output_tokens"],
        "perf": perf,
    }


def summary(rows):
    if len(rows) != 984 or len({r["task_id"] for r in rows}) != 984:
        raise ValueError("A final score requires all 984 QASPER validation questions")
    base = mean(r["baseline_f1"] for r in rows) * 100
    new = mean(r["new_f1"] for r in rows) * 100
    diffs = [r["new_f1"] - r["baseline_f1"] for r in rows]
    return {"questions":len(rows), "distinct_contexts":len({r["document_id"] for r in rows}),
            "metric":"normalized token F1 /100", "baseline":base, "new":new, "delta_points":new-base,
            "relative_change_pct":100*(new-base)/base, "higher":sum(d>0 for d in diffs),
            "equal":sum(d==0 for d in diffs), "lower":sum(d<0 for d in diffs),
            "baseline_mean_call_seconds":mean(r["baseline_call_seconds"] for r in rows),
            "new_mean_call_seconds":mean(r["call_seconds"] for r in rows)}


def run(complete, output_dir):
    """complete(messages: list[dict], max_tokens: int) -> (plain generated text, metrics dict)."""
    out = Path(output_dir)
    checkpoints = out / "qasper-r0-cases"
    checkpoints.mkdir(parents=True, exist_ok=True)
    results = []
    with (checkpoints / "run.lock").open("a+") as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        for i, case in enumerate(cases(), 1):
            path = checkpoints / (case["task_id"].split(":", 1)[1] + ".json")
            if path.exists():
                row = json.loads(path.read_text())
                expected = record(case, row["raw_output"], row["perf"], row["call_seconds"])
                if row != expected:
                    raise ValueError(f"Checkpoint mismatch: {path}")
            else:
                start = time.perf_counter()
                response, perf = complete(case["messages"], case["max_tokens"])
                row = record(case, response, perf, time.perf_counter()-start)
                write_json(path, row)
            results.append(row)
            if i % 25 == 0 or i in (1, 984):
                print(f"QASPER R0 {i}/984", flush=True)
        result = summary(results)
        write_json(out / "qasper-r0-summary.json", result)
        return result


if __name__ == "__main__":
    data = cases()
    print(f"Verified {len(data)} archived R0 cases. Qwen2.5 F1 = {100*mean(r['baseline_f1'] for r in data):.8f}")
