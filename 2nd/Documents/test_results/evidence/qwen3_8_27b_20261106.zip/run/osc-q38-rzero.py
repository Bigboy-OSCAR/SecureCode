"""Paired replay of the frozen R0 inputs. No inference happens on import."""
import fcntl
import gzip
import hashlib
import importlib.util
import json
import os
from pathlib import Path
import statistics
import sys
import time

ROOT = Path('/Users/oscar/Desktop/SecureCode')
EVIDENCE = ROOT / '2nd/Documents/test_results/evidence'
CODE_RUNNER = ROOT / '2nd/experiments/symbol_raptor/experiment.py'
METRICS = EVIDENCE / 'qasper_benchmark_20261027/source_snapshot/metrics.py'
FILES = {
    'small': 'r0_20261024/results.jsonl',
    'large': 'large_files_20261024/results.jsonl',
    'sensitivity': 'results_eval_budget512.jsonl',
    'qasper': 'qasper_benchmark_20261027/results.jsonl',
}
COUNTS = {'small': 288, 'large': 288, 'sensitivity': 48, 'qasper': 984}
SMALL_SYSTEM = 'You are a precise code analysis assistant. Follow output constraints exactly.'


def load_module(name, path):
    spec = importlib.util.spec_from_file_location(name, path)
    module = importlib.util.module_from_spec(spec)
    sys.dont_write_bytecode = True
    spec.loader.exec_module(module)
    return module


original = load_module('frozen_r0_experiment', CODE_RUNNER)
metrics = load_module('frozen_qasper_metrics', METRICS)


def read_rows(path):
    with path.open() as f:
        for line in f:
            yield json.loads(line)


def split_prompt(wrapped):
    start = '<|im_start|>system\n'
    middle = '<|im_end|>\n<|im_start|>user\n'
    end = '<|im_end|>\n<|im_start|>assistant\n'
    assert wrapped.startswith(start) and wrapped.endswith(end)
    system, user = wrapped[len(start):-len(end)].split(middle, 1)
    return [{'role': 'system', 'content': system}, {'role': 'user', 'content': user}]


def code_cases(suite, phase):
    path = EVIDENCE / FILES[suite]
    if phase == 'dev':
        path = path.with_name('results_dev.jsonl')
    for row in read_rows(path):
        if row['arm'] != 'R0':
            continue
        call = row['answer_call']
        wrapped = original._chat_wrap(call['prompt'])
        if 'request' in call:
            assert call['request']['prompt'] == wrapped
        correct = original.evaluate_answer(call, row['expected'])[0]
        assert correct == row['correct']
        yield {
            'task_id': row['task_id'], 'repeat': row['repeat'], 'expected': row['expected'],
            'category': row['category'], 'project': row['project'],
            'baseline_score': int(correct), 'baseline_answer_seconds': call['wall_seconds'],
            'messages': split_prompt(wrapped), 'limit': call['max_output_tokens'],
        }


def qasper_cases():
    folder = EVIDENCE / 'qasper_benchmark_20261027'
    tasks = {r['task_id']: r for r in read_rows(folder / 'tasks.jsonl')}
    scores = {r['task_id']: r['components']['f1'] for r in read_rows(folder / 'task_scores.jsonl') if r['arm'] == 'R0'}
    for row in read_rows(folder / 'results.jsonl'):
        if row['arm'] != 'R0':
            continue
        key, = row['call_keys']
        with gzip.open(folder / 'calls' / key[:2] / (key + '.json.gz')) as file:
            call = json.load(file)
        assert call['stage'] == 'answer' and call['status'] == 'ok'
        assert row['task_id'] == call['task_id'] and row['prediction'] == call['answer']
        task = tasks[row['task_id']]
        old_f1 = metrics.score_example('qasper', call['answer'], task['references'])['f1']
        assert abs(scores[row['task_id']] - old_f1) < 1e-12
        yield {
            'task_id': row['task_id'], 'repeat': 0, 'expected': task['references'],
            'category': 'qasper', 'project': task['document_id'],
            'baseline_score': old_f1, 'baseline_answer_seconds': call['wall_seconds'],
            'messages': split_prompt(call['request']['prompt']), 'limit': call['request']['n_predict'],
        }


def cases(suite, phase='eval'):
    if phase not in ('eval', 'dev') or phase == 'dev' and suite not in ('small','large'):
        raise ValueError('Only small and large have a dev phase')
    records = list(qasper_cases() if suite == 'qasper' else code_cases(suite, phase))
    assert len(records) == (COUNTS[suite] if phase == 'eval' else 8)
    assert len({(r['task_id'], r['repeat']) for r in records}) == len(records)
    for r in records:
        raw = json.dumps(r['messages'], ensure_ascii=False).encode()
        r['messages_sha256'] = hashlib.sha256(raw).hexdigest()
    return records


def eval_one(suite, case, answer, perf):
    if suite == 'qasper':
        return metrics.score_example('qasper', answer.strip(), case['expected'])['f1'], None
    reason = perf.get('finish_reason', perf.get('stop_reason'))
    if reason not in ('length', 'limit', 'max_tokens', 'stop', 'eos', 'stop_sequence', 'end_turn'):
        if 'stopped_limit' not in perf:
            raise ValueError('Callback must return stopped_limit or finish_reason to distinguish EOS from token cap')
    capped = bool(perf.get('stopped_limit')) or reason in ('length', 'limit', 'max_tokens')
    ok = not capped and not perf.get('truncated', False)
    correct, _, failure = original.evaluate_answer({'ok': ok, 'answer': answer}, case['expected'])
    return int(correct), failure


def summarize(rows):
    def mean(key):
        return statistics.mean(r[key] for r in rows)
    per_repeat = {}
    for rep in sorted({r['repeat'] for r in rows}):
        group = [r for r in rows if r['repeat'] == rep]
        per_repeat[rep] = {
            'n': len(group), 'old_score_percent': 100*statistics.mean(r['baseline_score'] for r in group),
            'new_score_percent': 100*statistics.mean(r['score'] for r in group),
        }
    old, new = mean('baseline_answer_seconds'), mean('answer_seconds')
    return {'answers': len(rows), 'questions':len({r['task_id'] for r in rows}),
            'old_score_percent': 100*mean('baseline_score'), 'new_score_percent': 100*mean('score'),
            'delta_points': 100*(mean('score')-mean('baseline_score')),
            'old_answer_seconds_mean': old, 'new_answer_seconds_mean': new,
            'answer_seconds_change_percent': 100*(new/old-1), 'repeats':per_repeat}


def run(generate, output, suite='small', phase='eval', run_id='Qwen3.8-27B-MLX-5bit'):
    """generate(messages, max_tokens) returns (answer, JSON-serializable metrics).
    Supply perf['finish_reason'] or perf['stopped_limit'] for code runs. Overall
    answer_seconds spans the callback (tokenization, prompt prefill, generation);
    source retrieval/packing is excluded on both sides. Run in a single process.
    Each output is exclusively locked; reuse it to resume precisely the same run.
    """
    records = cases(suite, phase)
    output = Path(output)
    output.parent.mkdir(parents=True, exist_ok=True)
    with output.open('a+b') as f:
        fcntl.flock(f, fcntl.LOCK_EX | fcntl.LOCK_NB)
        f.seek(0)
        rows = []
        while line := f.readline():
            if not line.endswith(b'\n'):
                f.truncate(f.tell()-len(line))
                break
            row = json.loads(line)
            case = records[len(rows)]
            assert (row['suite'],row['phase'],row['run_id'],row['task_id'],row['repeat'],row['messages_sha256']) == (
                suite,phase,run_id,case['task_id'],case['repeat'],case['messages_sha256'])
            rows.append(row)
        for case in records[len(rows):]:
            start = time.perf_counter()
            answer, perf = generate(case['messages'], case['limit'])
            elapsed = time.perf_counter()-start
            score, failure = eval_one(suite, case, answer, perf)
            row = {k:v for k,v in case.items() if k != 'messages'}
            row.update(suite=suite, phase=phase, run_id=run_id, answer=answer, metrics=perf, score=score,
                       failure=failure, answer_seconds=elapsed)
            f.write((json.dumps(row, ensure_ascii=False)+'\n').encode())
            f.flush()
            os.fsync(f.fileno())
            rows.append(row)
            if len(rows)%24 == 0:
                print(f'R0 {suite} {phase}: {len(rows)}/{len(records)}',flush=True)
    return summarize(rows)
