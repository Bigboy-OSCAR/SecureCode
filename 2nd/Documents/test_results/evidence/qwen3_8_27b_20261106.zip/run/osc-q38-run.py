from pathlib import Path
import argparse, datetime, fcntl, hashlib, importlib.metadata, json, os, runpy, sys, time

sys.dont_write_bytecode = True
BASE = Path('/private/tmp')
MODEL = Path('/Users/oscar/.lmstudio/models/lmstudio-community/Qwen3.8-27B-MLX-5bit')
OUT = Path('/private/tmp/osc-q38-results')
TREE = BASE/'osc-q38-tree.json'
REV = 'b9ad7b92aa2fd07b041f4b8b3aa459941f8abbf7'


def verify():
    records = json.loads(TREE.read_text())
    for r in records:
        path = MODEL / r['path']
        if path.stat().st_size != r['size']:
            raise ValueError(f'File size mismatch {path}')
        with path.open('rb') as f:
            if 'lfs' in r:
                expected = r['lfs']['oid']
                actual = hashlib.file_digest(f, 'sha256').hexdigest()
            else:
                expected = r['oid']
                actual = hashlib.sha1(f'blob {r["size"]}\0'.encode()+f.read()).hexdigest()
        if actual != expected:
            raise ValueError(f'Checksum mismatch {path}')
    print('Verified repository revision and every model file', flush=True)


def benchmark():
    import mlx.core as mx
    from mlx_lm import load, stream_generate
    from mlx_lm.sample_utils import make_sampler
    pointer = runpy.run_path(str(BASE/'osc-q38-pointer.py'))
    code = runpy.run_path(str(BASE/'osc-q38-rzero.py'))
    paper = runpy.run_path(str(BASE/'osc-q38-qasper.py'))
    print(mx.device_info(), flush=True)
    model, tokenizer = load(str(MODEL))
    print('Model ready', flush=True)
    identity = {'model':str(MODEL), 'revision':REV,'bits':5,'hardware':mx.device_info(),
                'temperature':0,'seed':1,'thinking':False,'prompt_cache':False,'batch_size':1,
                'packages':{k:importlib.metadata.version(k) for k in ['mlx','mlx-metal','mlx-lm','transformers']}}
    (OUT/'identity.json').write_text(json.dumps(identity, indent=2))
    sampler = make_sampler(temp=0)
    def complete(prompt, max_tokens, *, context, deadline=None):
        start = time.perf_counter()
        wrap_end = '<|im_end|>\n<|im_start|>assistant\n'
        if isinstance(prompt, str):
            assert prompt.endswith(wrap_end)
            text = prompt + '<think>\n\n</think>\n\n'
        else:
            text = tokenizer.apply_chat_template(prompt, tokenize=False, add_generation_prompt=True, enable_thinking=False)
            assert text.endswith(wrap_end + '<think>\n\n</think>\n\n')
        ids = tokenizer.encode(text, add_special_tokens=False)
        common = {'input_token_count':len(ids), 'formatted_input_sha256':hashlib.sha256(text.encode()).hexdigest()}
        is_pointer = isinstance(prompt, str)
        overflow = len(ids) > context - 4 if is_pointer else len(ids) + max_tokens > context
        if overflow:
            if not is_pointer:
                raise RuntimeError('R0 frozen prompt exceeds context limit')
            return '', {**common, 'returncode':1, 'error':'context_overflow'}
        def check_timeout(*args):
            if deadline is not None and time.perf_counter()-start > deadline:
                raise TimeoutError()
        pieces = []
        mx.random.seed(1)
        try:
            events = stream_generate(model,tokenizer,ids,max_tokens=max_tokens,sampler=sampler,
                                     prefill_step_size=512,prompt_progress_callback=check_timeout)
            for event in events:
                check_timeout()
                pieces.append(event.text)
        except TimeoutError:
            if not is_pointer:
                raise
            return '', {**common,'returncode':124,'error':'timeout'}
        finally:
            events.close()
        raw = ''.join(pieces)
        if not is_pointer:
            for marker in ('<|im_end|>','<|im_start|>'):
                if marker in raw:
                    raise ValueError('Unexpected generated chat boundary: '+repr(raw))
        perf = {**common,'prompt_tokens':event.prompt_tokens,'eval_tokens':event.generation_tokens,
                'prompt_tps':event.prompt_tps,'generation_tps':event.generation_tps,
                'prompt_eval_ms':1000*event.prompt_tokens/event.prompt_tps,'eval_ms':1000*event.generation_tokens/event.generation_tps,
                'peak_memory_gb':event.peak_memory,'finish_reason':event.finish_reason,'returncode':0}
        return raw, perf
    ptr = lambda prompt, limit: complete(prompt,limit,context=32768,deadline=300)
    r0 = lambda messages, limit: complete(messages,limit,context=8192)
    qa = lambda messages, limit: complete(messages,limit,context=32768)
    pointer['run_pointer_tests'](ptr, OUT/'pointers')
    for suite in ('small','large','sensitivity'):
        if suite in ('small','large') and not (OUT/f'{suite}-dev.jsonl').exists():
            warm = [{'role':'system','content':code['SMALL_SYSTEM']},{'role':'user','content':'Return only {"answer":0}.'}]
            for _ in range(2):
                r0(warm,32)
        if suite in ('small','large'):
            code['run'](r0,OUT/f'{suite}-dev.jsonl',suite=suite,phase='dev')
        summary=code['run'](r0,OUT/f'{suite}.jsonl',suite=suite)
        (OUT/f'{suite}-summary.json').write_text(json.dumps(summary,indent=2))
        print(summary, flush=True)
    print(paper['run'](qa,OUT/'qasper'),flush=True)

if __name__ == '__main__':
    OUT.mkdir(exist_ok=True)
    with (OUT/'worker.lock').open('a+') as lock:
        fcntl.flock(lock.fileno(), fcntl.LOCK_EX|fcntl.LOCK_NB)
        files = json.loads(TREE.read_text())
        while not all((MODEL / obj['path']).is_file() for obj in files):
            time.sleep(10)
        verify()
        benchmark()
