"""Replay both 1st-term SecureCode pointer suites with their original graders.

The caller supplies complete(wrapped_prompt, 128) -> (raw_model_output, metrics).
Use a fresh KV cache per call, greedy decoding, seed 1, no truncation, 32,768
tokens of context, and 300s per call. For context overflow return an empty
completion and nonzero returncode. Raise on infrastructure errors.
"""
import hashlib
import json
from pathlib import Path
import sys
import time
from unittest.mock import patch

ROOT = Path("/Users/oscar/Desktop/SecureCode/1st")
sys.path.insert(0, str(ROOT))
from source_pointer_test.source_pointer_bench import run_benchmark as source
from runtime_pointer_test.runtime_pointer_bench import run_benchmark as runtime

MODEL_ID = "lmstudio-community/Qwen3.8-27B-MLX-5bit"
CONTEXT = 32768
MAX_TOKENS = 128


def _transport(module, complete):
    def run(_args, prompt, purpose):
        wrapped = module._chat_wrap(prompt)
        t0 = time.monotonic()
        raw_text, metrics = complete(wrapped, MAX_TOKENS)
        elapsed = time.monotonic() - t0
        # Terminal formatting in original CLI was removed before scoring.
        # A callback may expose native reasoning separately from its raw record.
        answer = metrics.get("answer_text", raw_text).strip()
        return {
            **metrics,
            "purpose": purpose,
            "answer": answer,
            "raw_completion": raw_text,
            "wall_seconds": elapsed,
            "returncode": metrics.get("returncode", 0),
            "prompt_chars": len(prompt),
            "prompt_sha256": hashlib.sha256(wrapped.encode("utf-8")).hexdigest(),
            "estimated_prompt_tokens": max(1, round(len(prompt) / 4)),
            "prompt_eval_ms": metrics.get("prompt_eval_ms"),
            "prompt_tokens": metrics.get("prompt_tokens"),
            "eval_ms": metrics.get("eval_ms"),
            "eval_tokens": metrics.get("eval_tokens"),
        }
    return run


def _existing(path):
    if not path.exists():
        return {}
    rows = {}
    for line in path.read_text(encoding="utf-8").splitlines():
        row = json.loads(line)
        key = row["task_id"], row["mode"]
        if key in rows or row.get("model_id") != MODEL_ID:
            raise ValueError(f"Unexpected or duplicate prior result in {path}: {key}")
        rows[key] = row
    return rows


def _save(path, rows):
    temp = path.with_suffix(".jsonl.tmp")
    with temp.open("w", encoding="utf-8") as stream:
        for row in rows.values():
            stream.write(json.dumps(row, ensure_ascii=False) + "\n")
    temp.replace(path)


def run_pointer_tests(complete, output_dir):
    """Return 36 case dictionaries. Resume completed rows in four JSONL files."""
    output_dir = Path(output_dir)
    output_dir.mkdir(parents=True, exist_ok=True)
    results = []
    for suite, module in (("source", source), ("runtime", runtime)):
        for scale in ("small", "medium"):
            work = ROOT / f"{suite}_pointer_test" / "work"
            if module is source:
                corpus = work / scale
                manifest = source._read_json(corpus / "manifest.json")
                for item in manifest["sources"]:
                    if (corpus / "sources" / item["rel_path"]).stat().st_size != item["bytes"]:
                        raise ValueError(f"Original archived source size differs: {item['rel_path']}")
                tasks = source._read_json(corpus / "tasks.json")
                extra = (corpus, manifest, source.compact_catalog(manifest))
            else:
                tasks = runtime.runtime_tasks(scale, None, None, None)
                extra = ()
            path = output_dir / f"{suite}_{scale}.jsonl"
            rows = _existing(path)
            with patch.object(module, "_run_llama", _transport(module, complete)):
                for task in tasks:
                    for mode in module.DEFAULT_MODES:
                        key = (task["id"], mode)
                        if key in rows:
                            continue
                        print(f"Pointer {suite}/{scale}/{mode}/{task['id']}", flush=True)
                        result = module._run_case_mode(None, *extra, task, mode)
                        row = {
                            "model_id": MODEL_ID,
                            "suite": suite,
                            "scale": scale,
                            "run": 1,
                            "context_limit": CONTEXT,
                            "max_tokens": MAX_TOKENS,
                            "task_id": task["id"],
                            "question": task["question"],
                            "expected_substrings": task["expected_substrings"],
                            **result,
                        }
                        rows[key] = row
                        _save(path, rows)
            if len(rows) != len(tasks) * len(module.DEFAULT_MODES):
                raise ValueError(f"Unexpected results in {path}")
            results.extend(rows.values())
    return results
