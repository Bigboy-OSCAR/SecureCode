"""Build the Korean quantitative comparison from complete, matched benchmark results."""
import argparse
import json
from pathlib import Path
from statistics import mean
from docx import Document
from docx.enum.table import WD_TABLE_ALIGNMENT
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.oxml import OxmlElement
from docx.oxml.ns import qn
from docx.shared import Cm, Pt, RGBColor

BASE = Path('/Users/oscar/Desktop/SecureCode')
MODEL = 'lmstudio-community/Qwen3.8-27B-MLX-5bit'
SUITES = [('small', '소형 코드'), ('large', '대형 코드'), ('sensitivity', '근거 512토큰')]
CATEGORIES = {
    'single_function': '단일 함수', 'cross_file': '파일 간 관계', 'change_impact': '변경 영향',
    'boundary': '경계 조건', 'architecture': '아키텍처', 'semantic': '의미 해석',
}
FONT = 'Apple SD Gothic Neo'
INK = '18212C'
BLUE = '25435A'


def jsonlines(path):
    with path.open(encoding='utf-8') as f:
        return [json.loads(line) for line in f if line.strip()]


def paired_keys(rows):
    grouped = {(r['task_id'], r['mode']): r for r in rows}
    if len(grouped) != 9 or len(rows) != 9:
        raise ValueError('Missing or duplicate pointer results')
    return grouped


def load(root):
    pointer = {}
    code = {}
    for suite in ('source', 'runtime'):
        for scale in ('small', 'medium'):
            old = paired_keys(jsonlines(BASE / '1st' / (suite + '_pointer_test') / 'work' / (scale + '_final_results.jsonl')))
            new = paired_keys(jsonlines(root / 'pointers' / f'{suite}_{scale}.jsonl'))
            assert old.keys() == new.keys()
            groups = {'full': [], 'oracle': [], 'select': []}
            for k, o in old.items():
                r = new[k]
                assert r['model_id'] == MODEL and r['suite'] == suite and r['scale'] == scale
                assert o['expected_substrings'] == r['expected_substrings'] and o['question'] == r['question']
                mode = 'full' if k[1].startswith('full_') else k[1].split('_')[-1]
                groups[mode].append((o, r))
            assert all(len(v) == 3 for v in groups.values())
            pointer[suite, scale] = groups
    for suite, _ in SUITES:
        rows = jsonlines(root / (suite + '.jsonl'))
        expected = 48 if suite == 'sensitivity' else 288
        assert len(rows) == len({(r['task_id'], r['repeat']) for r in rows}) == expected
        assert set(r['category'] for r in rows) == CATEGORIES.keys()
        assert all(r['suite'] == suite and r['phase'] == 'eval' and r['baseline_score'] in (0, 1) and r['score'] in (0, 1) for r in rows)
        code[suite] = rows
    q = json.loads((root / 'qasper/qasper-r0-summary.json').read_text())
    assert q['questions'] == q['higher'] + q['equal'] + q['lower'] == 984 and q['distinct_contexts'] == 273
    assert abs((q['new'] - q['baseline']) - q['delta_points']) < 1e-8
    assert all(0 <= q[key] <= 100 for key in ('baseline', 'new'))
    from collections import defaultdict
    import numpy as np
    groups = defaultdict(list)
    for path in (root/'qasper'/'qasper-r0-cases').glob('*.json'):
        row = json.loads(path.read_text())
        groups[row['document_id']].append(100*(row['new_f1']-row['baseline_f1']))
    assert len(groups) == q['distinct_contexts'] and sum(map(len,groups.values())) == q['questions']
    vals = np.array([(len(groups[k]),sum(groups[k])) for k in sorted(groups)])
    samples = np.random.default_rng(1).integers(0,len(vals),size=(10000,len(vals)))
    draws = vals[samples].sum(axis=1)
    q['ci_low'], q['ci_high'] = np.quantile(draws[:,1]/draws[:,0],[0.025,0.975])
    return pointer, code, q


def delta(value, unit='%p', digits=1):
    sign = '+' if value > 0 else '−' if value < 0 else ''
    return f'{sign}{abs(value):.{digits}f}{unit}'


def proportion(count, n):
    return f'{count}/{n}  ({100*count/n:.1f}%)'


def tally(rows, key):
    return sum(r[key] for r in rows)


def setfont(run, size=None, bold=None, color=None):
    run.font.name = FONT
    rf = run._element.get_or_add_rPr().rFonts
    for key in ('ascii', 'hAnsi', 'eastAsia', 'cs'):
        rf.set(qn('w:' + key), FONT)
    if size is not None:
        run.font.size = Pt(size)
    if bold is not None:
        run.font.bold = bold
    if color:
        run.font.color.rgb = RGBColor.from_string(color)


def paragraph(doc, text, size=10, style=None, before=0, after=5, bold=False, color=INK):
    p = doc.add_paragraph(style=style)
    f = p.paragraph_format
    f.space_before, f.space_after = Pt(before), Pt(after)
    f.line_spacing = 1.18
    setfont(p.add_run(text), size, bold, color)
    return p


def heading(doc, text):
    return paragraph(doc, text, size=15, style='Heading 1', before=8, after=5, bold=True, color=BLUE)


def table(doc, labels, widths, records):
    t = doc.add_table(rows=0, cols=len(labels))
    t.alignment = WD_TABLE_ALIGNMENT.CENTER
    t.autofit = False
    for col, width in zip(t.columns, widths):
        col.width = Cm(width)
    margins = OxmlElement('w:tblCellMar')
    for side, x in [('top', 38), ('bottom', 38), ('left', 64), ('right', 64)]:
        node = OxmlElement('w:' + side)
        node.set(qn('w:w'), str(x))
        node.set(qn('w:type'), 'dxa')
        margins.append(node)
    t._tbl.tblPr.append(margins)
    for i, record in enumerate([labels] + records):
        row = t.add_row()
        row._tr.get_or_add_trPr().append(OxmlElement('w:cantSplit'))
        if i == 0:
            row._tr.get_or_add_trPr().append(OxmlElement('w:tblHeader'))
        for j, (cell, width, value) in enumerate(zip(row.cells, widths, record)):
            cell.width = Cm(width)
            shade = OxmlElement('w:shd')
            shade.set(qn('w:fill'), '29485D' if i == 0 else ('F0F4F6' if i % 2 else 'FFFFFF'))
            cell._tc.get_or_add_tcPr().append(shade)
            p = cell.paragraphs[0]
            p.paragraph_format.space_after = Pt(0)
            p.paragraph_format.space_before = Pt(0)
            p.paragraph_format.line_spacing = 1.11
            p.alignment = WD_ALIGN_PARAGRAPH.LEFT if j == 0 else WD_ALIGN_PARAGRAPH.RIGHT
            setfont(p.add_run(str(value)), 9.5, i == 0, 'FFFFFF' if i == 0 else INK)
    return t


def engine_seconds(row):
    calls = row['calls']
    if not calls or any(c['returncode'] != 0 or c.get('finish_reason') in ('length', 'limit', 'max_tokens')
                        or c.get('prompt_eval_ms') is None or c.get('eval_ms') is None for c in calls):
        return None
    return sum(c['prompt_eval_ms'] + c['eval_ms'] for c in calls) / 1000


def pointer_speed_rows(pointer):
    rows = []
    for suite, label in [('source', '소스'), ('runtime', '런타임')]:
        for mode, name in [('full', '전체 입력'), ('oracle', '지정 도구'), ('select', '모델이 도구 선택')]:
            pairs = [tuple(map(engine_seconds, pair)) for scale in ('small','medium')
                     for pair in pointer[suite, scale][mode]]
            matched = [pair for pair in pairs if None not in pair]
            if not matched:
                raise ValueError(f'No matched engine timings for {suite}/{mode}')
            old, new = map(mean, zip(*matched))
            rows.append([f'{label}  {name}', f'{len(matched)}/{len(pairs)}', f'{old:.2f}초', f'{new:.2f}초', delta(100*(new/old-1), '%')])
    return rows


def generate(data, target, latency):
    pointer, code, q = data
    doc = Document()
    sec = doc.sections[0]
    sec.page_width, sec.page_height = Cm(21), Cm(29.7)
    sec.left_margin = sec.right_margin = Cm(2.15)
    sec.top_margin, sec.bottom_margin = Cm(1.75), Cm(1.65)
    title = doc.styles['Title']
    title.font.color.rgb = RGBColor.from_string('000000')
    pp = title.element.find(qn('w:pPr'))
    if pp is not None:
        border = pp.find(qn('w:pBdr'))
        if border is not None:
            pp.remove(border)
    doc.core_properties.title = 'Qwen2.5와 Qwen3.8의 포인터 및 R0 성능 비교'
    doc.core_properties.subject = '테스트별 정답률과 논문 질의응답 점수 변화'
    doc.core_properties.author = 'SecureCode'
    paragraph(doc, 'Qwen2.5와 Qwen3.8의 성능 비교', 25, 'Title', after=4, bold=True, color='000000')
    paragraph(doc, 'Qwen2.5 Coder 7B Instruct Q5_K_M  →  Qwen3.8 27B MLX 5bit', 10, after=10, color=BLUE)
    small_delta = 100*mean(r['score']-r['baseline_score'] for r in code['small'])
    large_delta = 100*mean(r['score']-r['baseline_score'] for r in code['large'])
    paragraph(doc, f"R0 코드 정답률은 소형 {small_delta:.1f}%p, 대형 {large_delta:.1f}%p 올랐다. QASPER 평균 F1은 {q['delta_points']:.2f}점 올랐다.", 11, after=7, bold=True)
    overview = []
    for suite, label in [('source', '소스 포인터'), ('runtime', '런타임 포인터')]:
        pairs = [pair for scale in ('small', 'medium') for mode in ('oracle', 'select') for pair in pointer[suite, scale][mode]]
        old, new = [sum(pair[i]['correct'] for pair in pairs) for i in (0, 1)]
        overview.append(f'{label} {old}/12 → {new}/12')
    paragraph(doc, '도구를 사용한 조건의 정답 수는 ' + ', '.join(overview) + '였다.', 11, after=6)
    all_full = [pair for group in pointer.values() for pair in group['full']]
    completed = [sum(all(c['returncode'] == 0 for c in pair[i]['calls']) for pair in all_full) for i in (0,1)]
    correct = [sum(pair[i]['correct'] for pair in all_full) for i in (0,1)]
    paragraph(doc, f'전체 입력에서 답변을 낸 건수는 {completed[0]}/{len(all_full)} → {completed[1]}/{len(all_full)}, 정답 수는 {correct[0]}/{len(all_full)} → {correct[1]}/{len(all_full)}였다.',
              size=10.5, after=7)
    heading(doc, '포인터 테스트 정답률')
    records = []
    selections = []
    for suite, label in [('source', '소스'), ('runtime', '런타임')]:
        for mode, name in [('full','전체 입력'), ('oracle','지정 도구'), ('select','모델이 도구 선택')]:
            record = [label + '  ' + name]
            for scale in ('small','medium'):
                pairs = pointer[suite,scale][mode]
                old, new = [sum(pair[i]['correct'] for pair in pairs) for i in (0,1)]
                record.extend([f'{old}/3 → {new}/3', delta(100*(new-old)/3)])
            records.append(record)
        pairs = [pair for scale in ('small','medium') for pair in pointer[suite,scale]['select']]
        old, new = [sum(pair[i]['selection_correct'] for pair in pairs) for i in (0,1)]
        selections.append(f'{label} {old}/6 → {new}/6')
    table(doc, ['포인터와 조건', '소형 정답 수', '소형 증감', '중형 정답 수', '중형 증감'],
          [4.8, 3.2, 2.65, 3.25, 2.8], records)
    paragraph(doc, '모델이 고른 도구가 정답 근거를 추출한 건수는 ' + ', '.join(selections) + '이었다.',
              9.5, before=5, after=8)
    heading(doc, '포인터 테스트 추론 시간')
    paragraph(doc, '두 모델이 모두 처리한 문항의 평균 추론 시간(입력 처리+출력 생성)', size=9.5, after=4)
    table(doc, ['포인터와 조건', '비교 문항', '2.5 llama.cpp', '3.8 MLX', '시간 증감'],
          [4.8, 2.5, 3.2, 3.2, 3.0], pointer_speed_rows(pointer))
    doc.add_page_break()
    paragraph(doc, 'R0 인덱싱 성능', 23, 'Heading 1', after=5, bold=True, color='000000')
    rows = []
    for suite, name in SUITES:
        g = code[suite]
        n = len(g)
        old, new = tally(g,'baseline_score'), tally(g,'score')
        rows.append([name, proportion(old,n), proportion(new,n), delta(100*(new-old)/n)])
    heading(doc, '코드 질의응답 정답률')
    table(doc, ['코드 조건', '2.5 정답률', '3.8 정답률', '증감'], [4.5, 4.6, 4.6, 3.0], rows)
    paragraph(doc, '소형은 96문항 중 26개에서 62개, 대형은 25개에서 61개로 늘었다. 두 조건 모두 3회 반복에서 같은 정답 수를 기록했다.', 9.5, before=4)
    heading(doc, '질문 유형별 정답률 증감')
    categories = []
    for cat, name in CATEGORIES.items():
        changes = []
        for suite, _ in SUITES:
            group = [r for r in code[suite] if r['category'] == cat]
            changes.append(delta(100*mean(r['score']-r['baseline_score'] for r in group)))
        categories.append([name] + changes)
    table(doc, ['질문 유형', '소형 코드', '대형 코드', '근거 512토큰'], [5.3, 3.7, 3.7, 4.0], categories)
    heading(doc, 'QASPER 논문 질의응답')
    table(doc,['지표', '2.5', '3.8', '증감'], [5.3,3.7,3.7,4.0], [['평균 F1 (100점)', f"{q['baseline']:.2f}", f"{q['new']:.2f}", delta(q['delta_points'], '점', 2)]])
    paragraph(doc, f"논문 {q['distinct_contexts']}편의 {q['questions']}문항에서 F1이 오른 문항은 {q['higher']}개, 같은 문항은 {q['equal']}개, 내린 문항은 {q['lower']}개였다.", 10, before=5)
    paragraph(doc, f"F1 차이의 95% 신뢰구간은 {q['ci_low']:+.2f}~{q['ci_high']:+.2f}점이었다(논문 단위 짝지은 부트스트랩).", 9.5, after=4)
    if latency:
        heading(doc, '평균 답변 시간')
        timing = []
        for suite, name in SUITES + [('qasper','QASPER')]:
            if suite == 'qasper':
                old, new = q['baseline_mean_call_seconds'], q['new_mean_call_seconds']
            else:
                old, new = (mean(r[k] for r in code[suite]) for k in ('baseline_answer_seconds', 'answer_seconds'))
            timing.append([name, f'{old:.2f}초', f'{new:.2f}초', delta(100*(new/old-1), '%')])
        table(doc, ['코드 및 논문 조건', '2.5 llama.cpp', '3.8 MLX', '소요 시간 증감'], [4.65,4.05,4.05,3.95], timing)
    doc.save(str(target))


if __name__ == '__main__':
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('results', type=Path)
    parser.add_argument('output', type=Path)
    parser.add_argument('--latency', action='store_true', help='Only for serial comparable R0/QASPER timings.')
    args = parser.parse_args()
    generate(load(args.results), args.output, args.latency)
